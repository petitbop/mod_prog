var searchData=
[
  ['get',['get',['../class_dvector.html#a4934c6d6151f2260412d9bc4014feb96',1,'Dvector']]]
];
